Certainly! Below is the code with detailed comments explaining the functionality of each section:

```python
import argparse
import logging
import os
import time
import datetime

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
import torch.nn.functional as F
import pandas as pd
from torch_geometric.data import DataLoader
from model import GNN_LBA
from data import GNNTransformLBA
from atom3d.datasets import LMDBDataset, PTGDataset
from scipy.stats import spearmanr

# Set pandas options to display all columns and rows
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)

# Function to perform training for one epoch
def train_loop(model, loader, optimizer, device):
    model.train()  # Set the model to training mode

    loss_all = 0
    total = 0
    for data in loader:
        data = data.to(device)  # Move data to the specified device (CPU or GPU)
        optimizer.zero_grad()  # Clear previous gradients
        # Forward pass through the model
        output = model(data.x, data.edge_index, data.edge_attr.view(-1), data.batch)
        # Calculate mean squared error loss
        loss = F.mse_loss(output, data.y)
        loss.backward()  # Backpropagate the loss
        loss_all += loss.item() * data.num_graphs  # Accumulate the total loss
        total += data.num_graphs  # Count the number of graphs
        optimizer.step()  # Update the model parameters
    return np.sqrt(loss_all / total)  # Return the root mean square error

# Function to perform evaluation on validation or test data
@torch.no_grad()  # Disable gradient calculation
def test(model, loader, device):
    model.eval()  # Set the model to evaluation mode

    loss_all = 0
    total = 0

    y_true = []  # List to store true labels
    y_pred = []  # List to store predicted labels

    for data in loader:
        data = data.to(device)  # Move data to the specified device
        # Forward pass through the model
        output = model(data.x, data.edge_index, data.edge_attr.view(-1), data.batch)
        # Calculate mean squared error loss
        loss = F.mse_loss(output, data.y)
        loss_all += loss.item() * data.num_graphs  # Accumulate the total loss
        total += data.num_graphs  # Count the number of graphs
        y_true.extend(data.y.tolist())  # Store true labels
        y_pred.extend(output.tolist())  # Store predicted labels

    # Calculate Pearson correlation coefficient
    r_p = np.corrcoef(y_true, y_pred)[0,1]
    # Calculate Spearman correlation coefficient
    r_s = spearmanr(y_true, y_pred)[0]

    # Return RMSE, Pearson R, Spearman R, true labels, and predicted labels
    return np.sqrt(loss_all / total), r_p, r_s, y_true, y_pred

# Function to plot the correlation between true and predicted values
def plot_corr(y_true, y_pred, plot_dir):
    plt.clf()  # Clear the current figure
    sns.scatterplot(y_true, y_pred)  # Create a scatter plot
    plt.xlabel('Actual -log(K)')  # Set x-axis label
    plt.ylabel('Predicted -log(K)')  # Set y-axis label
    plt.savefig(plot_dir)  # Save the plot to the specified directory

# Function to save model weights
def save_weights(model, weight_dir):
    torch.save(model.state_dict(), weight_dir)

# Function to handle the training process
def train(args, device, log_dir, rep=None, test_mode=False):
    # Load datasets based on whether precomputed features are used
    if args.precomputed:
        train_dataset = PTGDataset(os.path.join(args.data_dir, 'train'))
        val_dataset = PTGDataset(os.path.join(args.data_dir, 'val'))
        test_dataset = PTGDataset(os.path.join(args.data_dir, 'test'))
    else:
        transform = GNNTransformLBA()
        train_dataset = LMDBDataset(os