Certainly! Below is the code with detailed comments explaining each part:

```python
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_add_pool

# Define the GNN model for Ligand Binding Affinity prediction
class GNN_LBA(torch.nn.Module):
    def __init__(self, num_features, hidden_dim):
        super(GNN_LBA, self).__init__()
        # Define the first graph convolutional layer
        self.conv1 = GCNConv(num_features, hidden_dim)
        # Define batch normalization for the first layer
        self.bn1 = nn.BatchNorm1d(hidden_dim)

        # Define the second graph convolutional layer
        self.conv2 = GCNConv(hidden_dim, hidden_dim*2)
        # Define batch normalization for the second layer
        self.bn2 = nn.BatchNorm1d(hidden_dim*2)

        # Define the third graph convolutional layer
        self.conv3 = GCNConv(hidden_dim*2, hidden_dim*4)
        # Define batch normalization for the third layer
        self.bn3 = nn.BatchNorm1d(hidden_dim*4)

        # Define the fourth graph convolutional layer
        self.conv4 = GCNConv(hidden_dim*4, hidden_dim*4)
        # Define batch normalization for the fourth layer
        self.bn4 = nn.BatchNorm1d(hidden_dim*4)

        # Define the fifth graph convolutional layer
        self.conv5 = GCNConv(hidden_dim*4, hidden_dim*8)
        # Define batch normalization for the fifth layer
        self.bn5 = nn.BatchNorm1d(hidden_dim*8)

        # Define the Global Attention Mechanism layer
        self.GAM_Attention = GAM_Attention(in_channels=hidden_dim*8, out_channels=hidden_dim*4)

        # Define the first fully connected layer
        self.fc1 = nn.Linear(256, 16)
        # Define the second fully connected layer
        self.fc2 = nn.Linear(16, 1)

    def forward(self, x, edge_index, edge_weight, batch):
        # Pass data through the first graph convolutional layer with ReLU activation and batch normalization
        x = self.conv1(x, edge_index, edge_weight)
        x = F.relu(x)
        x = self.bn1(x)

        # Pass data through the second graph convolutional layer with ReLU activation and batch normalization
        x = self.conv2(x, edge_index, edge_weight)
        x = F.relu(x)
        x = self.bn2(x)

        # Pass data through the third graph convolutional layer with ReLU activation and batch normalization
        x = self.conv3(x, edge_index, edge_weight)
        x = F.relu(x)
        x = self.bn3(x)

        # Pass data through the fourth graph convolutional layer with ReLU activation and batch normalization
        x = self.conv4(x, edge_index, edge_weight)
        x = self.bn4(x)
        x = F.relu(x)

        # Pass data through the fifth graph convolutional layer with batch normalization
        x = self.conv5(x, edge_index, edge_weight)
        x = self.bn5(x)

        # Apply global add pooling to summarize the node features for each graph
        x = global_add_pool(x, batch)

        # Reshape tensor for attention mechanism
        x = x.unsqueeze(-1).unsqueeze(-1)

        # Apply the Global Attention Mechanism
        x = self.GAM_Attention(x)

        # Remove the added dimensions
        x = x.squeeze(-1).squeeze(-1)

        # Pass data through the first fully connected layer
        x = self.fc1(x)

        # Pass data through the second fully connected layer and return the result
        return self.fc2(x).view(-1)

# Define the Global Attention Mechanism class
class GAM_Attention(nn.Module):
    def __init__(self, in_channels, out_channels, rate=4):
        super(GAM_Attention, self).__init__()

        # Define the channel attention mechanism
        self.channel_attention = nn.Sequential(
            nn.Linear(in_channels, int(in_channels / rate)),
            nn.ReLU(inplace=True),
            nn.Linear(int(in_channels / rate), in_channels)
        )

        #