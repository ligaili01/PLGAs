import numpy as np
import pandas as pd

import atom3d.datasets as da
import atom3d.protein.scop as sc

def test_get_scop_index():
    # TODO: write test for sc.get_scop_index()
    pass